part of '../constants.dart';

/// Filter value
const kSliderActiveColor = 0xFFffffff;
const kSliderInactiveColor = 0x99ffffff;
const kMaxPriceFilter = 100.0;
const kFilterDivision = 100;
