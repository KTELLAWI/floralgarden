part of '../constants.dart';

const Map awesomeIcon = {
  'whatsapp': Icons.chat_rounded,
  'phone': Icons.phone,
  'sms': Icons.sms_outlined,
  'google': Icons.chat,
  'facebookMessenger': Icons.facebook,
};
