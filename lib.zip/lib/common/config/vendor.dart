part of '../config.dart';

/// Everything Config about the Vendor Setting

/// Setting for Vendor Feature
Map get kVendorConfig => Configurations.vendorConfig;
