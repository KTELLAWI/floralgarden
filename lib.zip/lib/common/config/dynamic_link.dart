part of '../config.dart';

Map get firebaseDynamicLinkConfig => Configurations.firebaseDynamicLinkConfig;
