import '../vendor/store_model.dart';

class StoreDetailArgument {
  final Store? store;

  StoreDetailArgument({this.store});
}
